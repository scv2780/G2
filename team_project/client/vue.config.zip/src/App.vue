<!--
=========================================================
* Vue Material Dashboard 2 - v3.1.0
=========================================================

* Product Page: https://creative-tim.com/product/vue-material-dashboard-2
* Copyright 2023 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->
<template>
  <main
    class="main-content position-relative max-height-vh-100 h-100 overflow-x-hidden"
  >
    <!-- nav -->
    <navbar
      :class="[isNavFixed ? navbarFixed : '', isAbsolute ? absolute : '']"
      :color="isAbsolute ? 'text-white opacity-8' : ''"
      :minNav="navbarMinimize"
      v-if="showNavbar"
    />
    <router-view />
    <app-footer v-show="showFooter" />
    <configurator
      :toggle="toggleConfigurator"
      :class="[showConfig ? 'show' : '', hideConfigButton ? 'd-none' : '']"
    />
  </main>
</template>
<script>
import Configurator from '@/examples/Configurator.vue';
import Navbar from '@/examples/Navbars/Navbar.vue';
import AppFooter from '@/examples/Footer.vue';
import { mapMutations, mapState } from 'vuex';

export default {
  name: 'App',
  components: {
    Configurator,
    Navbar,
    AppFooter,
  },
  methods: {
    ...mapMutations(['toggleConfigurator', 'navbarMinimize']),
  },
  computed: {
    ...mapState([
      'isRTL',
      'color',
      'isAbsolute',
      'isNavFixed',
      'navbarFixed',
      'absolute',
      'showSidenav',
      'showNavbar',
      'showFooter',
      'showConfig',
      'hideConfigButton',
    ]),
  },
  beforeMount() {
    this.$store.state.isTransparent = 'bg-transparent';

    const sidenav = document.getElementsByClassName('g-sidenav-show')[0];

    if (window.innerWidth > 1200) {
      sidenav.classList.add('g-sidenav-pinned');
    }
  },
};
</script>
