import "./assets/js/nav-pills.js";
import "./assets/js/ripple-effect.js";
import "./assets/scss/material-dashboard.scss";

export default {
  install() {},
};
